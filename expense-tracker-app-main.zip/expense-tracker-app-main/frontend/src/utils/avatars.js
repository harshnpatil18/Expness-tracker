export const avatars = [
    {
        id: 1,
        url: 'https://avatars.dicebear.com/api/avataaars/1.svg'
    },
    {
        id: 2,
        url: 'https://avatars.dicebear.com/api/avataaars/2.svg'
    },
    {
        id: 3,
        url: 'https://avatars.dicebear.com/api/avataaars/3.svg'
    },
    {
        id: 4,
        url: 'https://avatars.dicebear.com/api/avataaars/4.svg'
    },
    {
        id: 5,
        url: 'https://avatars.dicebear.com/api/avataaars/5.svg'
    },
    {
        id: 6,
        url: 'https://avatars.dicebear.com/api/avataaars/6.svg'
    }
];
